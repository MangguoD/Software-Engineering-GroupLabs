#!/bin/bash
# 自动安装依赖工具（适用于 macOS）
brew update
brew install cppcheck cpplint lcov googletest